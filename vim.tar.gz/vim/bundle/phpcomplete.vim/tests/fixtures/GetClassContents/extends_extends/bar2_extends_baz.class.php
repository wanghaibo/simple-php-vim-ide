<?php

class BarClass2 extends BazClass { }
