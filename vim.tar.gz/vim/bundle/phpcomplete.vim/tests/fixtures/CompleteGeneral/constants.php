<?php

define('FINDME_FOO', 42);
define('DONT_FIND_ME', 6 * 7);
