<?php

class TagClass {
}

class lowercasetagclass {
}
