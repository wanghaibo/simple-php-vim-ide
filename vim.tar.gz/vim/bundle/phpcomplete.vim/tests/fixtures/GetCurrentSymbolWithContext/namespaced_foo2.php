<?php

namespace NS2;

class Foo2 {
	/**
	 * returnBaz
	 *
	 * @return Baz2
	 */
	public function returnBaz2() {

	}
}

class Baz2 {
	/**
	 * returnFoo2
	 *
	 * @return Foo2
	 */
	public function returnFoo2() {

	}
}
